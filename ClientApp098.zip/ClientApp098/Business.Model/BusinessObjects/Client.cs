﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Deployment.Internal;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace De.HsFlensburg.ClientApp098.Business.Model.BusinessObjects
{
    public class Client : INotifyPropertyChanged
    {
        private int id;
        private String name;

        public int Id
        {
            get { return id; }
            set { id = value; OnPropertChanged("Id"); }
        }

        public String Name 
        { 
            get { return name; }
            set { name = value; OnPropertChanged("Name"); }        
        }

        private void OnPropertChanged(string propertyname)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyname));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
